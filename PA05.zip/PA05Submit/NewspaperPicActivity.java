package andriodbootcamp.net.pa05;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class NewspaperPicActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_newspaper_pic);
    } // end method onCreate
} // end class NewspaperActivity
