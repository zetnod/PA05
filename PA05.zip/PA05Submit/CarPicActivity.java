package andriodbootcamp.net.pa05;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class CarPicActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_car_pic);
    } // end method onCreate
} // end class CarPicActivity
